# ArenaOS — Intelligent Stadium Operating System

**FIFA World Cup 2026 | Lusail International Stadium**

ArenaOS is a full-stack AI-powered stadium assistant built for FIFA World Cup 2026. It provides role-aware, context-grounded conversational AI across 9 operational domains — from navigation and emergency response to food queues and sustainability — all running on mock simulation data.

> All operational data in this project is **simulated for demonstration purposes**. No live stadium feeds are connected.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19 + Vite + TypeScript |
| Styling | Tailwind CSS v4 (dark glassmorphism theme) |
| Routing | Wouter |
| Animations | Framer Motion |
| Server state | TanStack Query v5 |
| Backend | Express 5 + Node.js (ESM) |
| Database | PostgreSQL via Drizzle ORM |
| AI | Google Gemini 2.5 Flash (via `@google/genai`) |
| API spec | OpenAPI 3.1 → generated TS client (Orval) |
| Monorepo | pnpm workspaces |
| Tests | Vitest |

---

## Features

### Chat-driven AI (all features share the same SSE streaming pipeline)

| Feature | What the AI does |
|---|---|
| **Navigation** | Routes fans to seats/gates using live crowd levels |
| **Crowd Intelligence** | Compares all 5 gates and recommends least-congested entry |
| **Emergency Assistant** | Surfaces nearest first-aid, fire assembly, or evacuation route. Escalates to 999 for life-threatening events |
| **Accessibility** | Generates barrier-free routes (elevators, ramps, assistance desks) |
| **Lost & Found** | Guides a structured multi-turn flow → produces a formal incident report |
| **Transportation Advisor** | Compares metro/bus/taxi wait times, flags delays/cancellations |
| **Sustainability Coach** | Recommends refill stations, recycling hubs, green exits with CO₂ estimates |
| **Food Finder** | Filters courts by dietary need (halal/vegan/vegetarian/gluten-free) and queue time |
| **Multilingual Support** | Responds in Spanish, French, Arabic, Hindi, or Tamil when selected |

### Organizer Command Center

- **AI Operational Summary** — Gemini synthesises 8 mock KPIs into a 3–4 sentence executive brief + 3 prioritised action recommendations, regenerated on demand
- **Announcement Generator** — Organizer types a situation; Gemini generates a professional PA announcement (translatable to 6 languages)

---

## How Structured Context Retrieval Works

ArenaOS does not use vector embeddings or RAG. Instead, the backend runs a lightweight **keyword + feature filter** before every Gemini call:

```
User message + active feature
        │
        ▼
┌──────────────────────────────┐
│  contextRetrieval.ts         │
│  – Checks active feature ID  │
│  – Scans message for ~50     │
│    domain keywords           │
│  – Selects matching data     │
│    blocks from mock JSON     │
└──────────────┬───────────────┘
               │ Only the matched subset
               ▼
     buildSystemPrompt()
     – Role instructions (fan/volunteer/staff/organizer)
     – Feature instructions (emergency/food/lost etc.)
     – Language instruction (if non-English)
     – Injected stadium data
               │
               ▼
     Gemini 2.5 Flash (SSE stream)
```

Each retrieval call logs its selection to stdout:
```
[ArenaOS Context Retrieval] Gates (all 5) + stadium layout — navigation feature=true
[ArenaOS Context Retrieval] Food courts (filtered: 4 open, dietary filter applied)
```

This makes the filtering behaviour fully transparent and demostrable without an ML pipeline.

**Why not RAG?**
The mock dataset is small (~50 records). Keyword filtering is deterministic, debuggable, and fast. RAG would add latency and complexity without accuracy benefit at this scale.

---

## Setting GEMINI_API_KEY

ArenaOS reads `GEMINI_API_KEY` from the server environment. **The key is never exposed to the browser.**

### On Replit (recommended)

1. Open your Repl
2. Click the **Secrets** tab (lock icon in the left sidebar)
3. Add a secret with key `GEMINI_API_KEY` and your Gemini API key as the value
4. The key is automatically available as `process.env.GEMINI_API_KEY` in the API server

Get a key at: https://aistudio.google.com/apikey

### Locally

```bash
export GEMINI_API_KEY=your_key_here
```

If the key is not set, the chat endpoint returns:
```json
{ "error": "Gemini API key not configured" }
```
and the UI displays a friendly error message.

---

## Running the Project

### Prerequisites

- Node.js 20+
- pnpm 9+
- PostgreSQL (or use the Replit built-in database — it's provisioned automatically)

### Install

```bash
pnpm install
```

### Database setup

```bash
pnpm --filter @workspace/db run push
```

### Run in development

The project uses Replit workflows. The two services are:

```bash
# API server (Express, port from $PORT)
pnpm --filter @workspace/api-server run dev

# Frontend (Vite, port from $PORT)
pnpm --filter @workspace/arena-os run dev
```

On Replit, press **Run** — both workflows start automatically.

### Run tests

```bash
pnpm --filter @workspace/api-server run test
```

Tests cover:
- `contextRetrieval.ts` — all 9 feature filters + keyword matching + dietary filtering + fallback
- `systemPrompt.ts` — role instructions, feature overlays, multilingual injection, context blocks
- Route validation — 400/404/503 guard logic for all endpoints

### Regenerate API client after spec changes

```bash
pnpm --filter @workspace/api-spec run codegen
```

---

## Project Structure

```
artifacts/
  arena-os/          # React + Vite frontend
    src/
      pages/         # Landing, Role, Dashboard, Chat, Organizer
      components/    # Layout, chat, organizer UI
      hooks/         # useChat (SSE streaming)
      data/          # Mock data (gates, food, transport, etc.)
      context/       # AppContext (role, language, conversation state)
  api-server/        # Express backend
    src/
      routes/
        gemini/      # Chat endpoints + system prompt + context retrieval
      data/          # Server-side copy of mock stadium data
      __tests__/     # Vitest test suite
lib/
  db/                # Drizzle schema (conversations, messages)
  api-spec/          # openapi.yaml → codegen source
  api-client-react/  # Generated TanStack Query hooks
  api-zod/           # Generated Zod validation schemas
```

---

## Simulation Mode

The amber **Simulation Mode** badge is visible in the top bar on every page where operational data is displayed. All data — crowd levels, queue times, transport status, incident counts — is mock static data defined in `src/data/` and `artifacts/api-server/src/data/`. 

No live stadium APIs are connected. This is intentional — the system is architected to swap in real data sources (IoT sensors, ticketing APIs, transport APIs) without changing the AI layer.

---

## Security Notes

- `GEMINI_API_KEY` is read only in the Express server process (`process.env.GEMINI_API_KEY`)
- The key is never bundled into the frontend Vite build
- All AI calls go through the backend — the browser never contacts Gemini directly
- The frontend communicates with the backend via `/api/*` routes proxied through Replit's gateway
